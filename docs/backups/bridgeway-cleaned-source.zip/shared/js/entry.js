location.replace('pages/home/index.html' + location.search + location.hash);
