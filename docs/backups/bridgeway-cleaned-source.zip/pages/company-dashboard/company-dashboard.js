/* Presentation enhancements scoped to the company workspace. */
document.addEventListener('DOMContentLoaded', () => {
  const weeklyCards = document.querySelectorAll('[data-weekly-id]');
  const weeklyWeek = document.getElementById('programWeekSelect');
  let weeklyStudentId = '1';
  function updateWeeklyWeek() {
    document.getElementById('weeklyReportWeek').textContent = `Week ${weeklyWeek.value} of 8`;
  }
  window.selectWeeklyIntern = (id, card, name) => {
    if (!['1','2'].includes(id) || !card) return;
    if (id !== weeklyStudentId) document.getElementById('companyWeeklyForm').reset();
    weeklyStudentId = id;
    document.getElementById('activeInternSelect').value = id;
    weeklyCards.forEach(item => {
      const selected = item.dataset.weeklyId === id;
      item.classList.toggle('is-active', selected);
      item.setAttribute('aria-pressed', String(selected));
    });
    document.getElementById('weeklyReportStudent').textContent = name;
    document.getElementById('weeklyReportRole').textContent = card.querySelector('.bw-intern-status-role').textContent;
    weeklyWeek.value = card.dataset.weeklyWeek;
    updateWeeklyWeek();
  };
  weeklyWeek.addEventListener('change', updateWeeklyWeek);
  weeklyCards.forEach(card => card.setAttribute('aria-pressed', String(card.classList.contains('is-active'))));
  const studentSelect = document.getElementById('evaluationStudentSelect');
  const studentOptions = Array.from(studentSelect.options);
  const studentSearch = document.getElementById('evaluationStudentSearch');
  let selectedStudent = studentSelect.value;
  studentSearch.addEventListener('input', () => {
    const query = studentSearch.value.trim().toLowerCase();
    studentSelect.replaceChildren(...studentOptions.filter(option => option.textContent.toLowerCase().includes(query)));
    studentSelect.value = selectedStudent;
    document.getElementById('evaluationStudentEmpty').hidden = studentSelect.options.length > 0;
  });
  studentSelect.addEventListener('change', () => {
    const option = studentSelect.selectedOptions[0];
    if (!option) return;
    window.selectInternForRubric(option.value, option.dataset.name, option.dataset.role, option.dataset.gpa, option.dataset.status);
  });
  // Keep selections made from the existing applicant Evaluate action in sync.
  const selectStudent = window.selectInternForRubric;
  window.selectInternForRubric = (id, ...details) => {
    if (!studentOptions.some(option => option.value === id)) return;
    if (id !== selectedStudent) {
      document.querySelectorAll('#rubricCriteriaContainer .is-active').forEach(button => button.classList.remove('is-active'));
      document.getElementById('evaluationComments').value = '';
      window.updateRubricHUD();
    }
    selectedStudent = id;
    studentSearch.value = '';
    studentSelect.replaceChildren(...studentOptions);
    studentSelect.value = id;
    document.getElementById('evaluationStudentEmpty').hidden = true;
    selectStudent(id, ...details);
  };
  const accountWrap = document.querySelector('.company-account-wrap');
  const accountToggle = document.getElementById('companyAccountToggle');
  const accountDropdown = document.getElementById('companyAccountDropdown');
  function setAccountOpen(open) {
    accountToggle.setAttribute('aria-expanded', String(open));
    accountDropdown.hidden = !open;
  }
  accountToggle.addEventListener('click', () => setAccountOpen(accountDropdown.hidden));
  accountToggle.addEventListener('keydown', event => {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setAccountOpen(true);
      accountDropdown.querySelector('a').focus();
    }
  });
  document.addEventListener('click', event => {
    if (!accountWrap.contains(event.target)) setAccountOpen(false);
  });
  document.addEventListener('focusin', event => {
    if (!accountWrap.contains(event.target)) setAccountOpen(false);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !accountDropdown.hidden) {
      setAccountOpen(false);
      accountToggle.focus();
    }
  });
  accountDropdown.addEventListener('click', event => {
    if (event.target.closest('a')) setAccountOpen(false);
  });
  const headings = {
    'tab-posts': ['Internship overview', 'A clear view of your opportunities, applicants, and interns.'],
    'tab-candidates': ['Applications', 'Review applicants to your company listings.'],
    'tab-partners': ['Partner colleges', 'Your company college connections and internship cycle.'],
    'tab-weekly-reports': ['Weekly reports', 'Choose an intern, then complete their report for the selected week.'],
    'tab-final-evaluation': ['Evaluations', 'Complete the internship evaluation required by the college at the end of term.']
  };
  function updateHeading() {
    const current = document.querySelector('.bw-tab-panel.is-active');
    const heading = headings[current?.id];
    if (!heading) return;
    document.querySelector('.bw-company-content').dataset.currentView = current.id;
    document.getElementById('companyPageTitle').textContent = heading[0];
    document.getElementById('companyPageDescription').textContent = heading[1];
    document.querySelectorAll('.bw-masar-nav [data-tab]').forEach(button => {
      if (button.dataset.tab === current.id) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    });
  }
  document.querySelectorAll('.bw-tab-panel').forEach(panel => {
    new MutationObserver(updateHeading).observe(panel, { attributes: true, attributeFilter: ['class'] });
  });
  updateHeading();
  const search = document.getElementById('companyListingSearch');
  const grid = document.querySelector('#tab-posts .bw-opportunities-grid');
  let listingStatus = 'all';
  function filterListings() {
    let visible = 0;
    grid.querySelectorAll('.bw-opp-card').forEach(card => {
      const matchesSearch = card.textContent.toLowerCase().includes(search.value.trim().toLowerCase());
      card.hidden = !matchesSearch || (listingStatus !== 'all' && card.dataset.listingStatus !== listingStatus);
      if (!card.hidden) visible++;
    });
    const empty = document.getElementById('companyListingsEmpty');
    empty.hidden = visible > 0;
    empty.textContent = grid.querySelector('.bw-opp-card') ? 'No matching internships. Try a different search or status.' : 'No internships yet. Post an internship to get started.';
    document.getElementById('companyListingCount').textContent = `Showing ${visible} of ${grid.querySelectorAll('.bw-opp-card').length} listings`;
    document.getElementById('kpiActivePosts').textContent = grid.querySelectorAll('[data-listing-status="active"]').length;
  }
  document.querySelectorAll('[data-listing-filter]').forEach(button => {
    button.addEventListener('click', () => {
      listingStatus = button.dataset.listingFilter;
      document.querySelectorAll('[data-listing-filter]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      filterListings();
    });
  });
  grid.querySelectorAll('[data-listing-details]').forEach(button => {
    button.addEventListener('click', () => {
      const detail = document.getElementById(button.getAttribute('aria-controls'));
      const open = detail.hidden;
      detail.hidden = !open;
      button.closest('.bw-opp-card').querySelectorAll('[data-listing-details]').forEach(item => item.setAttribute('aria-expanded', String(open)));
    });
  });
  grid.querySelectorAll('[data-listing-pause]').forEach(button => {
    button.onclick = null;
    button.addEventListener('click', () => {
      const row = button.closest('.bw-opp-card');
      const paused = row.dataset.listingStatus === 'active';
      row.dataset.listingStatus = paused ? 'paused' : 'active';
      row.querySelector('.post-status-badge').textContent = paused ? 'Paused' : 'Active';
      button.textContent = paused ? 'Resume listing' : 'Pause Post';
      filterListings();
      if (row.hidden) document.querySelector(`[data-listing-filter="${listingStatus}"]`).focus();
    });
  });
  search.addEventListener('input', filterListings);
  new MutationObserver(filterListings).observe(grid, { childList: true });
  filterListings();
  document.querySelectorAll('.bw-intern-status-card, .bw-intern-chip').forEach(card => {
    card.setAttribute('role', 'button');
    card.tabIndex = 0;
    card.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); card.click(); }
    });
  });
});

document.addEventListener('DOMContentLoaded',()=>{
 const id=new URLSearchParams(location.search).get('student');
 if(!['alice','ghaith'].includes(id))return;
 const option=document.querySelector(`#evaluationStudentSelect option[value="${id}"]`);
 if(location.hash==='#tab-final-evaluation' && option)window.selectInternForRubric(id,option.dataset.name,option.dataset.role,option.dataset.gpa,option.dataset.status);
 if(location.hash==='#tab-weekly-reports'){const card=document.querySelector(`[data-weekly-id="${id==='alice'?'1':'2'}"]`);window.selectWeeklyIntern(card.dataset.weeklyId,card,card.querySelector('.bw-intern-status-name').textContent);}
});

// Explicit handlers keep HTML presentation-only and preserve native event semantics.
(function () {
  document.querySelectorAll('[data-onclick="switchTab-tab-posts-1"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-posts') };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-candidates-2"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-candidates') };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-weekly-reports-3"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-weekly-reports') };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-final-evaluation-4"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-final-evaluation') };
  });
  document.querySelectorAll('[data-onclick="toggleCompanyPost--5"]').forEach(element => {
    element.onclick = function(event) { toggleCompanyPost(this) };
  });
  document.querySelectorAll('[data-onclick="openDeletePostModal--6"]').forEach(element => {
    element.onclick = function(event) { openDeletePostModal('Software Engineering Intern') };
  });
  document.querySelectorAll('[data-onclick="openDeletePostModal--7"]').forEach(element => {
    element.onclick = function(event) { openDeletePostModal('Frontend React Developer Intern') };
  });
  document.querySelectorAll('[data-onclick="filterCandidates-all-8"]').forEach(element => {
    element.onclick = function(event) { filterCandidates('all', this) };
  });
  document.querySelectorAll('[data-onclick="filterCandidates-accepted-9"]').forEach(element => {
    element.onclick = function(event) { filterCandidates('accepted', this) };
  });
  document.querySelectorAll('[data-onclick="filterCandidates-review-10"]').forEach(element => {
    element.onclick = function(event) { filterCandidates('review', this) };
  });
  document.querySelectorAll('[data-onclick="filterCandidates-awaiting-11"]').forEach(element => {
    element.onclick = function(event) { filterCandidates('awaiting', this) };
  });
  document.querySelectorAll('[data-oninput="searchCandidates--12"]').forEach(element => {
    element.oninput = function(event) { searchCandidates(this.value); };
  });
  document.querySelectorAll('[data-onclick="selectInternForRubric-alice-13"]').forEach(element => {
    element.onclick = function(event) { selectInternForRubric('alice', 'Alice Johnson', 'Frontend Developer Intern', '3.50', 'Ready for Final Evaluation'); window.switchTab('tab-final-evaluation'); };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-weekly-reports-14"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-weekly-reports'); };
  });
  document.querySelectorAll('[data-onclick="showPortalToast-tr-15"]').forEach(element => {
    element.onclick = function(event) { showPortalToast('Applicant seat approved and university advisor notified!'); this.closest('tr').querySelector('.bw-badge-amber').className = 'bw-badge bw-badge-success'; this.closest('tr').querySelector('.bw-badge-success').innerHTML = '<i class=\'bi bi-check-circle-fill\'></i> Accepted'; this.remove(); };
  });
  document.querySelectorAll('[data-onclick="selectWeeklyIntern--16"]').forEach(element => {
    element.onclick = function(event) { selectWeeklyIntern('1', this, 'Alice Johnson'); };
  });
  document.querySelectorAll('[data-onclick="selectWeeklyIntern--17"]').forEach(element => {
    element.onclick = function(event) { selectWeeklyIntern('2', this, 'Ghaith Amourah'); };
  });
  document.querySelectorAll('[data-onclick="selectWeeklyIntern--18"]').forEach(element => {
    element.onclick = function(event) { selectWeeklyIntern('3', this, 'Omar Majed'); };
  });
  document.querySelectorAll('[data-onsubmit="preventDefault--19"]').forEach(element => {
    element.onsubmit = function(event) { event.preventDefault(); showPortalToast('Report validated. Submission will be available when the backend is connected.'); };
  });
  document.querySelectorAll('[data-onclick="autoFillRubricDemo--20"]').forEach(element => {
    element.onclick = function(event) { autoFillRubricDemo(); };
  });
  document.querySelectorAll('[data-onclick="resetRubricRatings--21"]').forEach(element => {
    element.onclick = function(event) { resetRubricRatings(); };
  });
  document.querySelectorAll('[data-onclick="insertFeedbackText--22"]').forEach(element => {
    element.onclick = function(event) { insertFeedbackText('Demonstrated exceptional technical velocity, writing robust code and excelling in code reviews.'); };
  });
  document.querySelectorAll('[data-onclick="insertFeedbackText--23"]').forEach(element => {
    element.onclick = function(event) { insertFeedbackText('Active and proactive communicator during daily standups and engineering sprint planning.'); };
  });
  document.querySelectorAll('[data-onclick="insertFeedbackText--24"]').forEach(element => {
    element.onclick = function(event) { insertFeedbackText('Strongly endorsed for a full-time junior engineering offer upon university graduation.'); };
  });
  document.querySelectorAll('[data-onclick="showPortalToast--25"]').forEach(element => {
    element.onclick = function(event) { showPortalToast('Reminder preview only. No message was sent.'); };
  });
  document.querySelectorAll('[data-onclick="showPortalToast--26"]').forEach(element => {
    element.onclick = function(event) { showPortalToast('Calendar integration is a placeholder.'); };
  });
  document.querySelectorAll('[data-onclick="showPortalToast--27"]').forEach(element => {
    element.onclick = function(event) { showPortalToast('Interview preview only. No invitation was sent.'); };
  });
  document.querySelectorAll('[data-onclick="getElementById-replyFeedbackText-28"]').forEach(element => {
    element.onclick = function(event) { const t = document.getElementById('replyFeedbackText'); if (t && t.value.trim()) { showPortalToast('Feedback preview only. No message was sent.'); t.value = ''; closeModal('feedbackModal'); } else { showPortalToast('Please enter feedback message first.', 'bi-exclamation-triangle-fill text-warning'); } };
  });
})();
