// Explicit handlers keep HTML presentation-only and preserve native event semantics.
(function () {
  document.querySelectorAll('[data-onclick="switchTab-tab-progress-1"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-progress'); };
  });
  document.querySelectorAll('[data-onclick="openWithdrawModal--2"]').forEach(element => {
    element.onclick = function(event) { openWithdrawModal('Full-Stack .NET Developer Intern', 'Nexus Cloud Systems') };
  });
})();
