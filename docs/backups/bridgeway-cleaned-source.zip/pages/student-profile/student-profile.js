document.getElementById('studentProfileForm')?.addEventListener('submit', function(e) {
      e.preventDefault();
      showPortalToast('Profile validated in this preview. Changes are not saved.');
    });
