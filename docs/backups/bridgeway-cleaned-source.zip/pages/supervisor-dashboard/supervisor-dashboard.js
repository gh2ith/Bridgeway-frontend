/* Fixed examples for this supervisor; no backend, persistence, or editing. */
document.addEventListener('DOMContentLoaded',()=>{
 const records=[
  {id:'sarah',name:'Sarah Ahmad',studentId:window.BridgewayPartners.students.find(s=>s.id==='sarah').studentId,company:'Nexus Cloud Systems',role:'Full-Stack .NET Developer Intern',mentor:'Eng. Omar F.',date:'October 8, 2026',scores:[5,5,4,5,4,4,5,5],comments:'Sarah completed the training requirements and consistently delivered reliable work. She showed strong ownership and learned new tools quickly. Continue developing estimation skills and communicating blockers earlier.'},
  {id:'ghaith',name:'Ghaith Amourah',studentId:'20220148',company:'Tech Corp Inc.',role:'Software Engineering Intern',scores:null}
 ];
 const criteria=['Performance Level','Sense of Responsibility','Accuracy in Execution','Attendance & Punctuality','Teamwork & Collaboration','Adaptability & Flexibility','Speed of Learning','Curriculum Completion'];
 const ratings=['','Weak','Acceptable','Good','Very Good','Excellent'];
 const $=id=>document.getElementById(id);
 const make=(tag,text,cls)=>{const node=document.createElement(tag);if(text)node.textContent=text;if(cls)node.className=cls;return node;};
 let selected='sarah';
 function renderList(){
  const query=$('supervisorEvaluationSearch').value.trim().toLowerCase();
  const matches=records.filter(record=>`${record.name} ${record.studentId} ${record.company}`.toLowerCase().includes(query));
  const list=$('supervisorEvaluationStudents');list.replaceChildren();
  matches.forEach(record=>{const button=make('button',null,'evaluation-student-button');button.type='button';button.setAttribute('aria-pressed',String(record.id===selected));button.setAttribute('aria-controls','supervisorEvaluationSubmitted supervisorEvaluationPending');button.append(make('strong',record.name),make('span',`${record.studentId} / ${record.company}`),make('small',record.scores?'Submitted':'Not submitted'));button.addEventListener('click',()=>{selected=record.id;list.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));renderDetail();});list.append(button);});
  $('supervisorEvaluationCount').textContent=`${matches.length} of ${records.length} assigned students`;
  $('supervisorEvaluationEmpty').hidden=matches.length>0;
  document.querySelector('.evaluation-detail').hidden=matches.length===0;
 }
 function renderDetail(){
  const record=records.find(item=>item.id===selected);if(!record)return;
  $('supervisorEvaluationName').textContent=record.name;
  $('supervisorEvaluationIdentity').textContent=`${record.studentId} / ${record.company} / ${record.role}`;
  $('supervisorEvaluationStatus').textContent=record.scores?'Submitted':'Not submitted';
  $('supervisorEvaluationStatus').className=`bw-badge ${record.scores?'bw-badge-success':'bw-badge-amber'}`;
  $('supervisorEvaluationPending').hidden=Boolean(record.scores);
  $('supervisorEvaluationSubmitted').hidden=!record.scores;
  $('supervisorEvaluationScores').replaceChildren();
  for(const id of ['Company','Mentor','Date','Score','Comments'])$(`supervisorEvaluation${id}`).textContent='';
  if(!record.scores)return;
  $('supervisorEvaluationCompany').textContent=record.company;$('supervisorEvaluationMentor').textContent=record.mentor;$('supervisorEvaluationDate').textContent=record.date;
  const score=record.scores.reduce((sum,n)=>sum+n,0);$('supervisorEvaluationScore').textContent=`${score} / 40 (${score/40*100}%)`;
  record.scores.forEach((score,index)=>{const row=make('tr');const label=make('th',criteria[index]);label.scope='row';row.append(label,make('td',`${score} / 5`),make('td',ratings[score]));$('supervisorEvaluationScores').append(row);});
  $('supervisorEvaluationComments').textContent=record.comments;
 }
 $('supervisorEvaluationSearch').addEventListener('input',renderList);
 // Direct access from assigned student rows, without exposing another student's data.
 document.querySelectorAll('#supervisedStudentsTable tbody tr').forEach(row=>{const record=records.find(item=>row.textContent.includes(item.name));if(!record)return;const button=make('button','View evaluation','bw-tag-btn');button.type='button';button.addEventListener('click',()=>{selected=record.id;$('supervisorEvaluationSearch').value='';renderList();renderDetail();window.switchTab('tab-endorsement');});row.cells[row.cells.length-1].querySelectorAll('button').forEach(b=>{if(b.textContent.includes('View evaluation'))b.remove();});row.cells[row.cells.length-1].append(button);});
 renderList();renderDetail();
});

// Explicit handlers keep HTML presentation-only and preserve native event semantics.
(function () {
  document.querySelectorAll('[data-onclick="switchTab-tab-roster-1"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-roster'); };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-reports-2"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-reports'); };
  });
  document.querySelectorAll('[data-onclick="reviewStudentReport-GA-3"]').forEach(element => {
    element.onclick = function(event) { reviewStudentReport('Ghaith Amourah', 'Tech Corp Inc. • Company Mentor: Eng. Khalid T.', '240h / 320h', 'Week 6', 'GA') };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-endorsement-4"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-endorsement') };
  });
  document.querySelectorAll('[data-onclick="reviewStudentReport-SA-5"]').forEach(element => {
    element.onclick = function(event) { reviewStudentReport('Sarah Ahmad', 'Nexus Cloud Systems • Company Mentor: Eng. Omar F.', '320h / 320h', 'Week 8', 'SA') };
  });
})();
