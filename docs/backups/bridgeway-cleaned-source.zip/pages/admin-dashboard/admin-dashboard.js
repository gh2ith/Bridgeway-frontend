// Explicit handlers keep HTML presentation-only and preserve native event semantics.
(function () {
  document.querySelectorAll('[data-onclick="querySelector--1"]').forEach(element => {
    element.onclick = function(event) { document.querySelector('[data-tab=\'tab-users\']')?.click(); };
  });
  document.querySelectorAll('[data-onclick="querySelector--2"]').forEach(element => {
    element.onclick = function(event) { document.querySelector('[data-tab=\'tab-students\']')?.click(); };
  });
  document.querySelectorAll('[data-onclick="querySelector--3"]').forEach(element => {
    element.onclick = function(event) { document.querySelector('[data-tab=\'tab-companies\']')?.click(); };
  });
  document.querySelectorAll('[data-onclick="querySelector--4"]').forEach(element => {
    element.onclick = function(event) { document.querySelector('[data-tab=\'tab-supervisors\']')?.click(); };
  });
  document.querySelectorAll('[data-onclick="querySelector--5"]').forEach(element => {
    element.onclick = function(event) { document.querySelector('[data-tab=\'tab-posts\']')?.click(); };
  });
  document.querySelectorAll('[data-onclick="querySelector--6"]').forEach(element => {
    element.onclick = function(event) { document.querySelector('[data-tab=\'tab-approved\']')?.click(); };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-students-7"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-students') };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-supervisors-8"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-supervisors') };
  });
  document.querySelectorAll('[data-onclick="switchTab-tab-approved-9"]').forEach(element => {
    element.onclick = function(event) { window.switchTab('tab-approved') };
  });
  document.querySelectorAll('[data-onchange="showPortalToast--10"]').forEach(element => {
    element.onchange = function(event) { showPortalToast('Supervisor assigned successfully!') };
  });
  document.querySelectorAll('[data-onclick="openUnassignModal--11"]').forEach(element => {
    element.onclick = function(event) { openUnassignModal(1, 'Alice Johnson', 'Dr. John Smith') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Student-12"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Student', 1, 'Alice Johnson') };
  });
  document.querySelectorAll('[data-onclick="openUnassignModal--13"]').forEach(element => {
    element.onclick = function(event) { openUnassignModal(2, 'Ghaith Amourah', 'Dr. Ahmad S.') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Student-14"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Student', 2, 'Ghaith Amourah') };
  });
  document.querySelectorAll('[data-onclick="openUnassignModal--15"]').forEach(element => {
    element.onclick = function(event) { openUnassignModal(3, 'Sarah Ahmad', 'Dr. Ahmad S.') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Student-16"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Student', 3, 'Sarah Ahmad') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Supervisor-17"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Supervisor', 2, 'Dr. John Smith') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Supervisor-18"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Supervisor', 5, 'Dr. Ahmad S.') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Post-19"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Post', 1, 'Software Engineering Intern') };
  });
  document.querySelectorAll('[data-onclick="openDeleteModal-Post-20"]').forEach(element => {
    element.onclick = function(event) { openDeleteModal('Post', 2, 'Frontend React Developer Intern') };
  });
  document.querySelectorAll('[data-onclick="openTerminateModal--21"]').forEach(element => {
    element.onclick = function(event) { openTerminateModal(101, 'Alice Johnson', 'Full-Stack .NET Developer') };
  });
  document.querySelectorAll('[data-onclick="openTerminateModal--22"]').forEach(element => {
    element.onclick = function(event) { openTerminateModal(102, 'Ghaith Amourah', 'Software Engineering Intern') };
  });
})();
